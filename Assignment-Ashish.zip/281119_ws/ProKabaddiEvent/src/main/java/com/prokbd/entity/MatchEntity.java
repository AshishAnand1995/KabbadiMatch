package com.prokbd.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.prokbd.utility.LocalDateTimeAtrributeConverter;

import lombok.Data;

@Entity
@Table(name = "kabddi_match")
@Data
public class MatchEntity implements Serializable {
	
	
	
	  
	  /**
	 * Ashish Anand
	 */
	private static final long serialVersionUID = 1L;

	@Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	  private Long id;
	  
	  @Column(name = "homeTeamId")
	  private Long homeTeamId;
	  
	  @Column(name = "awayTeamId")
	  private Long awayTeamId;
	  
	  @Column(name = "matchDate")
	  @Convert(converter=LocalDateTimeAtrributeConverter.class)
	  private LocalDateTime matchDate;
	  
	
	  private String location;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getHomeTeamId() {
		return homeTeamId;
	}

	public void setHomeTeamId(Long homeTeamId) {
		this.homeTeamId = homeTeamId;
	}

	public Long getAwayTeamId() {
		return awayTeamId;
	}

	public void setAwayTeamId(Long awayTeamId) {
		this.awayTeamId = awayTeamId;
	}

	public LocalDateTime getMatchDate() {
		return matchDate;
	}

	public void setMatchDate(LocalDateTime matchDate) {
		this.matchDate = matchDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "MatchEntity [id=" + id + ", homeTeamId=" + homeTeamId + ", awayTeamId=" + awayTeamId + ", matchDate="
				+ matchDate + ", location=" + location + "]";
	}
	  
	  
	
	}
	
	
	
	


