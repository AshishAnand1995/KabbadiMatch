package com.prokbd;

import java.util.Collections;

import org.dozer.DozerBeanMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
//@ComponentScan({"com.prokbd.DAO","com.prokbd.entity","com.prokbd.service","com.prokbd.controller","com.prokbd.utility"})
public class ProKabaddiEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProKabaddiEventApplication.class, args);
	}
	
	
	  @Bean 
	  public DozerBeanMapper dozerBean() { DozerBeanMapper dozerBean= new
	  DozerBeanMapper();
	  dozerBean.setMappingFiles(Collections.singletonList("dozerJdk8Converters.xml")); return dozerBean; }
	
	//dozerJdk8Converters.xml
}