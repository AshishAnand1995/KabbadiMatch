package com.prokbd.entity;

import java.io.Serializable;

public interface ResponseModel extends Serializable
{
  
}
