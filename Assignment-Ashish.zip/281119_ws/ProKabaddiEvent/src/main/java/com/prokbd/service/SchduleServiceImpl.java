package com.prokbd.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prokbd.DAO.SchduledDAO;
import com.prokbd.DAO.TeamDAO;
import com.prokbd.entity.Match;
import com.prokbd.entity.MatchEntity;
import com.prokbd.entity.Team;
import com.prokbd.entity.TeamEntity;

@Service
public class SchduleServiceImpl implements SchduleService {
	
	private Logger logger = LoggerFactory.getLogger(SchduleServiceImpl.class.getSimpleName());
	
	
	@Autowired
     private SchduledDAO schduledDAO1;
	
	@Autowired
	private TeamDAO teamDAO;
	
	

	  @Autowired 
	  private DozerBeanMapper mapper;
	 
	
	private  LocalDateTime startDateTime;

	private  List<Match> generate ( )
	  {
	    logger.info("Generating schedule ...");
	    List<Match> matches = new ArrayList<>();
	    //List<TeamEntity> hoEntities=new ArrayList<TeamEntity>();
	    try {
	   
	    Iterator<TeamEntity> homeTeamIterator =teamDAO.findAll().iterator();
	     //hoEntities=teamDAO.findAll();
	                                                                                              
	    List<Team> homeTeamList = new ArrayList<>();
	
			
			 while ( homeTeamIterator.hasNext() ){
			  homeTeamList.add(mapper.map(homeTeamIterator.next(), Team.class));
			  
			  }
			 
	    
	    List<Team> awayTeamList = new ArrayList<>(homeTeamList);
	
	    
	    /**
	     * create a cross matches
	     * Team will act here once as home and once away
	     */
	    for ( Team homeTeam : homeTeamList )
	    {
	      for ( Team awayTeam : awayTeamList )
	      {
	        if ( homeTeam.getId() != awayTeam.getId() )
	        {
	          Match match = new Match();
	          match.setAwayTeamId(awayTeam.getId());
	          match.setHomeTeamId(homeTeam.getId());
	          
	          /**
	           * will satisfied the home and away constraints
	           */
	          
	          match.setLocation(homeTeam.getCity());
	          MatchEntity matchEntity = mapper.map(match, MatchEntity.class);
	          logger.info("Match Created : {}", matchEntity);
	          matches.add(mapper.map(schduledDAO1.save(matchEntity), Match.class));
	       //   matches.add
	        }
	      }
	    }
	    
	    /**
	     * Update the matchDate for cross match considering below constraints.
	     * 
	     * Maximum 2 matches per day are allowed
	     * No team should play on consecutive days
	     */
	    while ( matches.stream().filter(match -> match.getMatchDate() == null).count() != 0 )
	    {
	      List<Match> pendingMatchList = matches.stream().filter(match -> match.getMatchDate() == null)
	          .collect(Collectors.toList());
	      
	      for ( Match match : pendingMatchList )
	      {
	        /**
	         * Collect the matches for localDateTime 
	         */
	        List<Match> currentDayMatchList = matches.stream()
	            .filter(currentDayMatch -> currentDayMatch.getMatchDate() != null
	                && currentDayMatch.getMatchDate().isEqual(startDateTime))
	            .collect(Collectors.toList());
	        
	        /**
	         * Collect the matches for localDateTime - 1  
	         */
	        List<Match> previousMatchList = matches.stream()
	            .filter(previousDayMatch -> previousDayMatch.getMatchDate() != null
	                && previousDayMatch.getMatchDate().isEqual(startDateTime.minusDays(1)))
	            .collect(Collectors.toList());
	        
	        /**
	         *  Max 2 matches per day.
	         *  No team should play on consecutive days
	         */
	        if ( currentDayMatchList.size() < 2
	            && currentDayMatchList.stream().filter(currentMatch -> currentMatch.isTeamMatch(match)).count() == 0
	            && previousMatchList.stream().filter(prevMatch -> prevMatch.isTeamMatch(match)).count() == 0 ){
	            match.setMatchDate(startDateTime);
	            MatchEntity matchEntity = mapper.map(match, MatchEntity.class);
	            //matchRepository.save(matchEntity);
	            schduledDAO1.save(matchEntity);
	            //entityManager.persist(matchEntity);
	            logger.info(" MatchDateUpdated  : {}", match);
	        }
	      }
	      /**
	       *  move to next day
	       */
	      startDateTime = startDateTime.plusDays(1);
	    }
	    
	    /**
	     * sort list based on matchDate
	     */
	    matches.sort(Comparator.comparing(Match::getMatchDate));
	    }
	    catch (Exception e) {
			// TODO: handle exception
	    	logger.error("Exception caught .........................."+e.getMessage());
		}
	    return matches;
	  }

	  private void initStartDate(LocalDateTime startDateTime)
	  {
	    this.startDateTime = startDateTime;
	  }
	  
	  @Override
	  public List<Match> initStartDateAndGenerateSchedule (LocalDateTime startDateTime )
	  {
	    initStartDate(startDateTime);
	    return generate();
	  }



}
