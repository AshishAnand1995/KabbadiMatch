package com.prokbd.apptest;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prokbd.entity.Match;
import com.prokbd.entity.Team;

//@RunWith(SpringRunner.class)
//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProKabaddiEventTest {

	
	

	/*
	 * @LocalServerPort private int port;
	 */
	   
	   @Autowired
	   private TestRestTemplate restTemplate;
	    
	   /**
	    * dummy test for adding  team
	    */
	   @Test
	   public void add()
	   {
	     Team team = new Team();
	     team.setId(1);
	     team.setName("TestTeam");
	     team.setDescription("TestDescription");
	     team.setCity("testCity");
	     HttpEntity<Team> request = new HttpEntity<Team>(team);
	     assertThat(this.restTemplate.postForObject("http://localhost:8080/prokabadi/team/add/", request,
	         Team.class)).isEqualTo(team);
	   }
	   
	   
	   
	   
	    
	}
	
	
	
	
	
	
	

