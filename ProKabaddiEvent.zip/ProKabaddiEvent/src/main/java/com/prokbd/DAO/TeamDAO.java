package com.prokbd.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.prokbd.entity.TeamEntity;

@Repository
public interface TeamDAO extends JpaRepository<TeamEntity, Long> {

}
