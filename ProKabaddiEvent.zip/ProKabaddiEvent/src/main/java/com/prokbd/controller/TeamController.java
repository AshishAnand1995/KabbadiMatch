package com.prokbd.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.prokbd.entity.ResponseModel;
import com.prokbd.entity.Team;
import com.prokbd.entity.TeamEntity;
import com.prokbd.service.TeamService;
import com.prokbd.service.TeamServiceImpl;

@RestController
@RequestMapping(path = "/prokabadi/team")
public class TeamController
{
	
	public static final Logger logger = LoggerFactory.getLogger(TeamController.class);
  
  @Autowired
  private TeamService teamService;
  
  /**
   * persist single team
   */
	/*
	 * @PostMapping(path = "/add", consumes="application/json",
	 * produces="application/json") public ResponseModel add ( @RequestBody Team
	 * team ) { return teamService.add(team); }
	 */
  
  
  @RequestMapping(value = "/add/", method = RequestMethod.POST)
  public ResponseEntity<TeamEntity> add(@RequestBody TeamEntity teamEntity, UriComponentsBuilder ucBuilder) {
      logger.info("Creating Team : {}");

		/*
		 * if (teamService.isUserExist(user)) {
		 * logger.error("Unable to create. A User with name {} already exist",
		 * user.getName()); return new ResponseEntity(new
		 * CustomErrorType("Unable to create. A User with name " + user.getName() +
		 * " already exist."),HttpStatus.CONFLICT); }
		 */
     

      TeamEntity teamEntity2=teamService.addTeam(teamEntity);
      HttpHeaders headers = new HttpHeaders();
      //headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(user.getId()).toUri());
      return new ResponseEntity<TeamEntity>(teamEntity2,headers, HttpStatus.CREATED);
  }
  
  
  /**
   * persist team list
   */
  
	/*
	 * @RequestMapping(value ="/add/all", method = RequestMethod.POST) public
	 * ResponseEntity<List<Team>> addAll(@RequestBody List<Team> teamList) {
	 * List<Team> teams= teamService.add(teamList); return new
	 * ResponseEntity<>(teams, HttpStatus.CREATED); }
	 */
  
  /**
   * FIXME get, getAll, update, updateAll
   */
}