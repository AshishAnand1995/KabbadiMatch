package com.prokbd.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.aspectj.weaver.patterns.ParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prokbd.entity.Match;
import com.prokbd.service.SchduleService;

@RestController
@RequestMapping(path = "/prokabadi/schedule")
public class MatchScheduleController {

	public static final Logger logger = LoggerFactory.getLogger(TeamController.class);

	@Autowired
	private SchduleService schduleService;

	@RequestMapping(value = {"/generate/{startDate}" }, method = RequestMethod.GET)
	public ResponseEntity<List<Match>> generate(@PathVariable Optional<String> startDate) {

		List<Match> list = null;
		LocalDateTime dateTime=null;
		try { 
String date=startDate.get();
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
dateTime = LocalDateTime.parse(date, formatter);
		}
catch (ParserException e) {
	// TODO: handle exception
	logger.error("Exception caught"+e.getMessage());
}
//System.out.println(date);
		
			LocalDateTime startDateTime = startDate.isPresent() ? dateTime : LocalDateTime.now().plusDays(1);
			//String startDateTime=startDate.isPresent() ? startDate : LocalDateTime.now().plusDays(1);
			list = schduleService.initStartDateAndGenerateSchedule(startDateTime);
		
		return new ResponseEntity<List<Match>>(list, HttpStatus.OK);
	}

	

}
