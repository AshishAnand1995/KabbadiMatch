package com.prokbd.service;

import java.time.LocalDateTime;
import java.util.List;

import com.prokbd.entity.Match;

public interface SchduleService {
	
	  public abstract List<Match> initStartDateAndGenerateSchedule (LocalDateTime startDateTime );
}
