package com.prokbd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prokbd.DAO.TeamDAO;
import com.prokbd.entity.TeamEntity;

@Service
public class TeamServiceImpl implements TeamService{
	
	
	@Autowired
	private TeamDAO teamDAO1;
	

	
@Override

	public TeamEntity addTeam(TeamEntity teamEntity) {
		// TODO Auto-generated method stub
		teamDAO1.save(teamEntity);
		return teamEntity;
	}

}
