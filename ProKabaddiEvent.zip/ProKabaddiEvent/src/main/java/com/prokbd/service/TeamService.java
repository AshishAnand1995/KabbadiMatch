package com.prokbd.service;

import java.util.List;



import com.prokbd.entity.TeamEntity;

public interface TeamService {

	
	public TeamEntity addTeam(TeamEntity teamEntity);
	
	/*
	 * public abstract List<Team> add(List<Team> teamList); public abstract
	 * ResponseModel add(RequestModel model); public TeamEntity addTeam(TeamEntity
	 * teamEntity);
	 */
}
