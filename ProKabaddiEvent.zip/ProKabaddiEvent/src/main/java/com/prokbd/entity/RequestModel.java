package com.prokbd.entity;

import java.io.Serializable;

public interface RequestModel extends Serializable
{
  
}