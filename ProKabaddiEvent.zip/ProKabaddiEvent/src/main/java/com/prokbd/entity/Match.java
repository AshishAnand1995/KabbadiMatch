package com.prokbd.entity;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class Match implements ResponseModel
{
  
  private static final long serialVersionUID = 1004193081628327382L;
  private long id;
  private long homeTeamId;
  private long awayTeamId;
  private LocalDateTime matchDate;
  private String location;
  
  /**
   *  check team relation
   *  like two matches are related based on there teams? 
   */
  
  
  
  
  
  public boolean isTeamMatch ( Match match )
  {
    return (match != null && match instanceof Match)
        && (this.homeTeamId == match.homeTeamId || this.homeTeamId == match.awayTeamId
            || this.awayTeamId == match.awayTeamId || this.awayTeamId == match.homeTeamId);
  }

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public long getHomeTeamId() {
	return homeTeamId;
}

public void setHomeTeamId(long homeTeamId) {
	this.homeTeamId = homeTeamId;
}

public long getAwayTeamId() {
	return awayTeamId;
}

public void setAwayTeamId(long awayTeamId) {
	this.awayTeamId = awayTeamId;
}

public LocalDateTime getMatchDate() {
	return matchDate;
}

public void setMatchDate(LocalDateTime matchDate) {
	this.matchDate = matchDate;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}
  
}
